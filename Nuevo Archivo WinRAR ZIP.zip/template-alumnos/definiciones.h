#ifndef SOLUCION_DEFINICIONES_H
#define SOLUCION_DEFINICIONES_H

#include <vector>

using namespace std;

using pixel = vector<int>;
using imagen = vector<vector<int>>;
using sqPixel = vector<pixel>;

#endif //SOLUCION_DEFINICIONES_H
